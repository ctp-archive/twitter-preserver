window.YTD.following.part0 = [
  {
    "following" : {
      "accountId" : "1509587599794454528",
      "userLink" : "https://twitter.com/intent/user?user_id=1509587599794454528"
    }
  }
]