window.YTD.personalization.part0 = [
  {
    "p13nData" : {
      "demographics" : {
        "languages" : [
          {
            "language" : "English",
            "isDisabled" : false
          }
        ],
        "genderInfo" : {
          "gender" : ""
        }
      },
      "interests" : {
        "interests" : [
          {
            "name" : "Twitter",
            "isDisabled" : false
          }
        ],
        "partnerInterests" : [ ],
        "audienceAndAdvertisers" : {
          "numAudiences" : "0",
          "advertisers" : [ ],
          "lookalikeAdvertisers" : [
            "@StarbucksCanada",
            "@Tabnine_"
          ],
          "doNotReachAdvertisers" : [ ]
        },
        "shows" : [ ]
      },
      "locationHistory" : [
        "Monterey, CA, USA"
      ],
      "inferredAgeInfo" : {
        "age" : [
          "13-54"
        ],
        "birthDate" : ""
      }
    }
  }
]