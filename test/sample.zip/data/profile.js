window.YTD.profile.part0 = [
  {
    "profile" : {
      "description" : {
        "bio" : "A test Twitter account for the preservation of downloaded Twitter archives.",
        "website" : "",
        "location" : ""
      },
      "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/1497320640931516418/KBhQoFvP.jpg",
      "headerMediaUrl" : "https://pbs.twimg.com/profile_banners/1497319353372405762/1645824082"
    }
  }
]