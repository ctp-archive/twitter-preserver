window.YTD.account.part0 = [
  {
    "account" : {
      "email" : "kevin.miller@ucsf.edu",
      "createdVia" : "oauth:3033300",
      "username" : "preservationi19",
      "accountId" : "1497319353372405762",
      "createdAt" : "2022-02-25T21:15:35.800Z",
      "accountDisplayName" : "preservationisttest"
    }
  }
]