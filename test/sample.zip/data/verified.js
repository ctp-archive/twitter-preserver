window.YTD.verified.part0 = [
  {
    "verified" : {
      "accountId" : "1497319353372405762",
      "verified" : false
    }
  }
]