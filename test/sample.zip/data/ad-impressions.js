window.YTD.ad_impressions.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Prime Video",
                "screenName" : "@PrimeVideo"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-03-15 16:53:06"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Prime Video",
                "screenName" : "@PrimeVideo"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-03-15 20:26:33"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Best Deal Search",
                "screenName" : "@bestdealsearch"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2022-03-15 20:26:48"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1473085115148353536",
                "tweetText" : "Doorvest launches in Dallas, further expanding within Texas! See why here: https://t.co/vRT5amsNMJ https://t.co/5OsXZuBDDU",
                "urls" : [
                  "https://t.co/vRT5amsNMJ"
                ],
                "mediaUrls" : [
                  "https://t.co/5OsXZuBDDU"
                ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Doorvest",
                "screenName" : "@doorvestco"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-03-15 20:26:48"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Prime Video",
                "screenName" : "@PrimeVideo"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-03-15 17:19:34"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Prime Video",
                "screenName" : "@PrimeVideo"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-03-15 17:19:35"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1503437627478867968",
                "tweetText" : "CODA writer / director Siân Heder &amp; her formidable cast continue to make history! Winner 2 BAFTA Awards + Critics Choice Award. Nominated for 3 #AcademyAwards - Best Picture, Supporting Actor &amp; Adapted Screenplay. Watch #CODAFilm only on @AppleTVplus. https://t.co/w1eZv0AAIP",
                "urls" : [
                  "https://t.co/w1eZv0AAIP"
                ],
                "mediaUrls" : [ ]
              },
              "promotedTrendInfo" : {
                "trendId" : "86714",
                "name" : "#AppleTVPlus20220315",
                "description" : ""
              },
              "advertiserInfo" : {
                "advertiserName" : "Apple TV+",
                "screenName" : "@AppleTVPlus"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-03-15 17:19:39"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "ProfileAccountsSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Avalanche 🔺",
                "screenName" : "@avalancheavax"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "#link"
                },
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "$link"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "21 to 49"
                }
              ],
              "impressionTime" : "2022-03-15 17:19:43"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1503471096141529089",
                "tweetText" : "CODA writer / director Siân Heder &amp; her formidable cast continue to make history! Winner 2 BAFTA Awards + Critics Choice Award. Nominated for 3 #AcademyAwards - Best Picture, Supporting Actor &amp; Adapted Screenplay. Watch #CODAFilm only on @AppleTVplus. https://t.co/w1eZv0AAIP",
                "urls" : [
                  "https://t.co/w1eZv0AAIP"
                ],
                "mediaUrls" : [ ]
              },
              "promotedTrendInfo" : {
                "trendId" : "86716",
                "name" : "#AppleTVPlus20220316",
                "description" : ""
              },
              "advertiserInfo" : {
                "advertiserName" : "Apple TV+",
                "screenName" : "@AppleTVPlus"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-03-16 19:59:26"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "XPENG",
                "screenName" : "@XPengMotors"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-03-16 19:59:25"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "XPENG",
                "screenName" : "@XPengMotors"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United States"
                }
              ],
              "impressionTime" : "2022-03-16 19:59:27"
            }
          ]
        }
      }
    }
  }
]