window.YTD.ad_engagements.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86605",
                  "name" : "#TheTragedyOfMacbeth",
                  "description" : "Now Streaming on Apple TV+"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Apple TV+",
                  "screenName" : "@AppleTVPlus"
                },
                "impressionTime" : "2022-03-09 15:53:46"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-03-09 15:53:47",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "82956",
                  "name" : "#FirstBushmills",
                  "description" : "Your first whiskey of St. Patrick’s Day is on us."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Bushmills USA",
                  "screenName" : "@BushmillsUSA"
                },
                "impressionTime" : "2022-03-14 19:10:20"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-03-14 19:10:22",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86710",
                  "name" : "#AlzheimersInAmerica",
                  "description" : "More than 6 million Americans are living with Alzheimer’s."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Alzheimer's Association",
                  "screenName" : "@alzassociation"
                },
                "impressionTime" : "2022-03-15 16:51:59"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-03-15 16:52:00",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86710",
                  "name" : "#AlzheimersInAmerica",
                  "description" : "More than 6 million Americans are living with Alzheimer’s."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Alzheimer's Association",
                  "screenName" : "@alzassociation"
                },
                "impressionTime" : "2022-03-15 16:53:09"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-03-15 16:53:10",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86710",
                  "name" : "#AlzheimersInAmerica",
                  "description" : "More than 6 million Americans are living with Alzheimer’s."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Alzheimer's Association",
                  "screenName" : "@alzassociation"
                },
                "impressionTime" : "2022-03-15 16:54:21"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-03-15 16:54:22",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86710",
                  "name" : "#AlzheimersInAmerica",
                  "description" : "More than 6 million Americans are living with Alzheimer’s."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Alzheimer's Association",
                  "screenName" : "@alzassociation"
                },
                "impressionTime" : "2022-03-15 16:53:06"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-03-15 16:53:07",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86710",
                  "name" : "#AlzheimersInAmerica",
                  "description" : "More than 6 million Americans are living with Alzheimer’s."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Alzheimer's Association",
                  "screenName" : "@alzassociation"
                },
                "impressionTime" : "2022-03-15 16:51:00"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-03-15 16:51:01",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86710",
                  "name" : "#AlzheimersInAmerica",
                  "description" : "More than 6 million Americans are living with Alzheimer’s."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Alzheimer's Association",
                  "screenName" : "@alzassociation"
                },
                "impressionTime" : "2022-03-15 15:50:50"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-03-15 15:50:51",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86710",
                  "name" : "#AlzheimersInAmerica",
                  "description" : "More than 6 million Americans are living with Alzheimer’s."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Alzheimer's Association",
                  "screenName" : "@alzassociation"
                },
                "impressionTime" : "2022-03-15 15:50:14"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-03-15 15:50:15",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86710",
                  "name" : "#AlzheimersInAmerica",
                  "description" : "More than 6 million Americans are living with Alzheimer’s."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Alzheimer's Association",
                  "screenName" : "@alzassociation"
                },
                "impressionTime" : "2022-03-15 20:24:12"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-03-15 20:24:13",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86710",
                  "name" : "#AlzheimersInAmerica",
                  "description" : "More than 6 million Americans are living with Alzheimer’s."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Alzheimer's Association",
                  "screenName" : "@alzassociation"
                },
                "impressionTime" : "2022-03-15 20:26:33"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-03-15 20:26:33",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1473085115148353536",
                  "tweetText" : "Doorvest launches in Dallas, further expanding within Texas! See why here: https://t.co/vRT5amsNMJ https://t.co/5OsXZuBDDU",
                  "urls" : [
                    "https://t.co/vRT5amsNMJ"
                  ],
                  "mediaUrls" : [
                    "https://t.co/5OsXZuBDDU"
                  ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Doorvest",
                  "screenName" : "@doorvestco"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States"
                  }
                ],
                "impressionTime" : "2022-03-15 20:26:33"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-03-15 20:26:48",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86710",
                  "name" : "#AlzheimersInAmerica",
                  "description" : "More than 6 million Americans are living with Alzheimer’s."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Alzheimer's Association",
                  "screenName" : "@alzassociation"
                },
                "impressionTime" : "2022-03-15 19:55:04"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-03-15 19:55:05",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86710",
                  "name" : "#AlzheimersInAmerica",
                  "description" : "More than 6 million Americans are living with Alzheimer’s."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Alzheimer's Association",
                  "screenName" : "@alzassociation"
                },
                "impressionTime" : "2022-03-15 17:19:34"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-03-15 17:19:34",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1503437627478867968",
                  "tweetText" : "CODA writer / director Siân Heder &amp; her formidable cast continue to make history! Winner 2 BAFTA Awards + Critics Choice Award. Nominated for 3 #AcademyAwards - Best Picture, Supporting Actor &amp; Adapted Screenplay. Watch #CODAFilm only on @AppleTVplus. https://t.co/w1eZv0AAIP",
                  "urls" : [
                    "https://t.co/w1eZv0AAIP"
                  ],
                  "mediaUrls" : [ ]
                },
                "promotedTrendInfo" : {
                  "trendId" : "86714",
                  "name" : "#AppleTVPlus20220315",
                  "description" : ""
                },
                "advertiserInfo" : {
                  "advertiserName" : "Apple TV+",
                  "screenName" : "@AppleTVPlus"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United States"
                  }
                ],
                "impressionTime" : "2022-03-15 17:19:33"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-03-15 17:19:39",
                  "engagementType" : "VideoContentPlaybackStart"
                },
                {
                  "engagementTime" : "2022-03-15 17:19:42",
                  "engagementType" : "VideoSession"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86710",
                  "name" : "#AlzheimersInAmerica",
                  "description" : "More than 6 million Americans are living with Alzheimer’s."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Alzheimer's Association",
                  "screenName" : "@alzassociation"
                },
                "impressionTime" : "2022-03-15 17:19:08"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-03-15 17:19:09",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86710",
                  "name" : "#AlzheimersInAmerica",
                  "description" : "More than 6 million Americans are living with Alzheimer’s."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Alzheimer's Association",
                  "screenName" : "@alzassociation"
                },
                "impressionTime" : "2022-03-15 17:18:30"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-03-15 17:18:31",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86744",
                  "name" : " #AsWeWork",
                  "description" : "Listen to WSJ's new podcast about our rapidly changing work lives."
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Wall Street Journal",
                  "screenName" : "@WSJ"
                },
                "impressionTime" : "2022-03-16 19:05:30"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-03-16 19:05:30",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86744",
                  "name" : " #AsWeWork",
                  "description" : "Listen to WSJ's new podcast about our rapidly changing work lives."
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Wall Street Journal",
                  "screenName" : "@WSJ"
                },
                "impressionTime" : "2022-03-16 19:48:59"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-03-16 19:49:00",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86744",
                  "name" : " #AsWeWork",
                  "description" : "Listen to WSJ's new podcast about our rapidly changing work lives."
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Wall Street Journal",
                  "screenName" : "@WSJ"
                },
                "impressionTime" : "2022-03-16 19:17:55"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-03-16 19:17:56",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86744",
                  "name" : " #AsWeWork",
                  "description" : "Listen to WSJ's new podcast about our rapidly changing work lives."
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Wall Street Journal",
                  "screenName" : "@WSJ"
                },
                "impressionTime" : "2022-03-16 19:03:57"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-03-16 19:03:57",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86744",
                  "name" : " #AsWeWork",
                  "description" : "Listen to WSJ's new podcast about our rapidly changing work lives."
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Wall Street Journal",
                  "screenName" : "@WSJ"
                },
                "impressionTime" : "2022-03-16 19:02:53"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-03-16 19:02:54",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86744",
                  "name" : " #AsWeWork",
                  "description" : "Listen to WSJ's new podcast about our rapidly changing work lives."
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Wall Street Journal",
                  "screenName" : "@WSJ"
                },
                "impressionTime" : "2022-03-16 19:02:32"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-03-16 19:02:32",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86744",
                  "name" : " #AsWeWork",
                  "description" : "Listen to WSJ's new podcast about our rapidly changing work lives."
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Wall Street Journal",
                  "screenName" : "@WSJ"
                },
                "impressionTime" : "2022-03-16 19:59:24"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-03-16 19:59:25",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86744",
                  "name" : " #AsWeWork",
                  "description" : "Listen to WSJ's new podcast about our rapidly changing work lives."
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Wall Street Journal",
                  "screenName" : "@WSJ"
                },
                "impressionTime" : "2022-03-16 19:03:07"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-03-16 19:03:08",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86744",
                  "name" : " #AsWeWork",
                  "description" : "Listen to WSJ's new podcast about our rapidly changing work lives."
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Wall Street Journal",
                  "screenName" : "@WSJ"
                },
                "impressionTime" : "2022-03-16 19:04:49"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-03-16 19:04:49",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86744",
                  "name" : " #AsWeWork",
                  "description" : "Listen to WSJ's new podcast about our rapidly changing work lives."
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Wall Street Journal",
                  "screenName" : "@WSJ"
                },
                "impressionTime" : "2022-03-16 19:43:59"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-03-16 19:44:00",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86744",
                  "name" : " #AsWeWork",
                  "description" : "Listen to WSJ's new podcast about our rapidly changing work lives."
                },
                "advertiserInfo" : {
                  "advertiserName" : "The Wall Street Journal",
                  "screenName" : "@WSJ"
                },
                "impressionTime" : "2022-03-16 19:18:20"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-03-16 19:18:20",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86793",
                  "name" : "#DisneyPlus",
                  "description" : "More heroes. More Marvel."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@disneyplus"
                },
                "impressionTime" : "2022-03-17 15:54:21"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-03-17 15:54:22",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86793",
                  "name" : "#DisneyPlus",
                  "description" : "More heroes. More Marvel."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@disneyplus"
                },
                "impressionTime" : "2022-03-17 16:25:16"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-03-17 16:25:17",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86793",
                  "name" : "#DisneyPlus",
                  "description" : "More heroes. More Marvel."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Disney+",
                  "screenName" : "@disneyplus"
                },
                "impressionTime" : "2022-03-17 16:25:14"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-03-17 16:25:15",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "86801",
                  "name" : "#GoldfishMegaBites",
                  "description" : "Experience the MEGA"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Goldfish®",
                  "screenName" : "@GoldfishSmiles"
                },
                "impressionTime" : "2022-03-22 23:16:03"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-03-22 23:16:05",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  }
]