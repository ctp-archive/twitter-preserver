window.YTD.account_timezone.part0 = [
  {
    "accountTimezone" : {
      "accountId" : "1497319353372405762"
    }
  }
]