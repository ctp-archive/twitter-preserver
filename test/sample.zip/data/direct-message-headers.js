window.YTD.direct_message_headers.part0 = [
  {
    "dmConversation" : {
      "conversationId" : "1497319353372405762-1509587599794454528",
      "messages" : [
        {
          "messageCreate" : {
            "id" : "1509588915065217032",
            "senderId" : "1509587599794454528",
            "recipientId" : "1497319353372405762",
            "createdAt" : "2022-03-31T17:50:18.967Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1509588659846074378",
            "senderId" : "1497319353372405762",
            "recipientId" : "1509587599794454528",
            "createdAt" : "2022-03-31T17:49:17.998Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1509588518556758025",
            "senderId" : "1509587599794454528",
            "recipientId" : "1497319353372405762",
            "createdAt" : "2022-03-31T17:48:44.447Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1509588420804313098",
            "senderId" : "1509587599794454528",
            "recipientId" : "1497319353372405762",
            "createdAt" : "2022-03-31T17:48:21.017Z"
          }
        },
        {
          "messageCreate" : {
            "id" : "1509588362159550472",
            "senderId" : "1497319353372405762",
            "recipientId" : "1509587599794454528",
            "createdAt" : "2022-03-31T17:48:07.027Z"
          }
        }
      ]
    }
  }
]