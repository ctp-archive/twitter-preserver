window.YTD.ad_online_conversions_unattributed.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "unattributedOnlineConversions" : {
          "conversions" : [
            {
              "conversionTime" : "2022-03-23 16:32:13",
              "advertiserInfo" : {
                "advertiserName" : "Airtable",
                "screenName" : "@airtable"
              },
              "conversionPlatform" : "Desktop",
              "conversionValue" : "0"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "unattributedOnlineConversions" : {
          "conversions" : [
            {
              "conversionTime" : "2022-03-23 20:45:53",
              "advertiserInfo" : {
                "advertiserName" : "Airtable",
                "screenName" : "@airtable"
              },
              "conversionPlatform" : "Desktop",
              "conversionValue" : "0"
            },
            {
              "eventType" : "pageview",
              "conversionPlatform" : "Desktop",
              "conversionUrl" : "https://www.everlaw.com/blog/2020/01/04/introducing-the-everlaw-api/",
              "advertiserInfo" : {
                "advertiserName" : "Everlaw",
                "screenName" : "@everlaw"
              },
              "conversionValue" : "0",
              "conversionTime" : "2022-03-23 17:12:19",
              "additionalParameters" : {
                "contentName" : "Any"
              }
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "unattributedOnlineConversions" : {
          "conversions" : [
            {
              "eventType" : "purchase",
              "conversionPlatform" : "Desktop",
              "conversionUrl" : "https://www.zillow.com/port-townsend-wa/",
              "advertiserInfo" : {
                "advertiserName" : "Zillow",
                "screenName" : "@zillow"
              },
              "conversionValue" : "0",
              "conversionTime" : "2022-03-24 20:14:57",
              "additionalParameters" : {
                "numItems" : "0"
              }
            },
            {
              "eventType" : "pageview",
              "conversionPlatform" : "Desktop",
              "conversionUrl" : "https://www.zillow.com/port-townsend-wa/",
              "advertiserInfo" : {
                "advertiserName" : "Zillow",
                "screenName" : "@zillow"
              },
              "conversionValue" : "0",
              "conversionTime" : "2022-03-24 20:14:57",
              "additionalParameters" : { }
            },
            {
              "conversionPlatform" : "Desktop",
              "conversionUrl" : "https://www.zillow.com/port-townsend-wa/",
              "advertiserInfo" : {
                "advertiserName" : "Zillow",
                "screenName" : "@zillow"
              },
              "conversionValue" : "0",
              "conversionTime" : "2022-03-24 20:14:58"
            },
            {
              "eventType" : "pageview",
              "conversionPlatform" : "Desktop",
              "conversionUrl" : "https://www.zillow.com/port-townsend-wa/",
              "advertiserInfo" : {
                "advertiserName" : "Zillow",
                "screenName" : "@zillow"
              },
              "conversionValue" : "0",
              "conversionTime" : "2022-03-24 20:14:57",
              "additionalParameters" : { }
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "unattributedOnlineConversions" : {
          "conversions" : [
            {
              "conversionTime" : "2022-03-28 14:26:25",
              "advertiserInfo" : {
                "advertiserName" : "Airtable",
                "screenName" : "@airtable"
              },
              "conversionPlatform" : "Desktop",
              "conversionValue" : "0"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "unattributedOnlineConversions" : {
          "conversions" : [
            {
              "eventType" : "pageview",
              "conversionPlatform" : "Desktop",
              "conversionUrl" : "https://linktr.ee/",
              "advertiserInfo" : {
                "advertiserName" : "Linktree",
                "screenName" : "@Linktree_"
              },
              "conversionValue" : "0",
              "conversionTime" : "2022-03-28 20:15:57",
              "additionalParameters" : { }
            },
            {
              "eventType" : "pageview",
              "conversionPlatform" : "Desktop",
              "conversionUrl" : "https://www.theverge.com/2022/3/28/22999719/spam-texts-own-phone-number-verizon-att-tmobile?utm_source=nextdraft&utm_medium=email",
              "advertiserInfo" : {
                "advertiserName" : "The Verge",
                "screenName" : "@verge"
              },
              "conversionValue" : "0",
              "conversionTime" : "2022-03-28 20:42:12",
              "additionalParameters" : { }
            },
            {
              "conversionTime" : "2022-03-28 20:10:10",
              "conversionPlatform" : "Desktop",
              "conversionUrl" : "https://cdn.krxd.net/"
            },
            {
              "eventType" : "pageview",
              "conversionPlatform" : "Desktop",
              "conversionUrl" : "https://alexsteffen.substack.com/p/thinking-about-planetary-discontinuity",
              "advertiserInfo" : {
                "advertiserName" : "Alex Steffen",
                "screenName" : "@AlexSteffen"
              },
              "conversionValue" : "0",
              "conversionTime" : "2022-03-28 22:52:58",
              "additionalParameters" : { }
            },
            {
              "eventType" : "pageview",
              "conversionPlatform" : "Desktop",
              "conversionUrl" : "https://zoom.us/",
              "advertiserInfo" : {
                "advertiserName" : "Zoom",
                "screenName" : "@Zoom"
              },
              "conversionValue" : "0",
              "conversionTime" : "2022-03-28 22:38:25",
              "additionalParameters" : { }
            },
            {
              "conversionTime" : "2022-03-28 22:11:34",
              "advertiserInfo" : {
                "advertiserName" : "Airtable",
                "screenName" : "@airtable"
              },
              "conversionPlatform" : "Desktop",
              "conversionValue" : "0"
            },
            {
              "eventType" : "pageview",
              "conversionPlatform" : "Desktop",
              "conversionUrl" : "https://app.slack.com/ssb/add?s=1&v=4.24.1&ssb_vid=.48ah1j6h4mjoi63b0qpi99xkh&ssb_instance_id=3967af6d-6207-5922-b2a7-e343d568532b#/select",
              "advertiserInfo" : {
                "advertiserName" : "Slack",
                "screenName" : "@SlackHQ"
              },
              "conversionValue" : "0",
              "conversionTime" : "2022-03-28 18:04:10",
              "additionalParameters" : { }
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "unattributedOnlineConversions" : {
          "conversions" : [
            {
              "eventType" : "pageview",
              "conversionPlatform" : "Desktop",
              "conversionUrl" : "https://slack.com/",
              "advertiserInfo" : {
                "advertiserName" : "Slack",
                "screenName" : "@SlackHQ"
              },
              "conversionValue" : "0",
              "conversionTime" : "2022-03-29 18:26:21",
              "additionalParameters" : { }
            },
            {
              "eventType" : "pageview",
              "conversionPlatform" : "Desktop",
              "conversionUrl" : "https://ucsf.zoom.us/?mn=Z5B9RkRBJO6JU0NxqoyQcFquIigOOiF1ND0.ZnzAOcw5v4SLi-kt",
              "advertiserInfo" : {
                "advertiserName" : "Zoom",
                "screenName" : "@Zoom"
              },
              "conversionValue" : "0",
              "conversionTime" : "2022-03-29 21:10:51",
              "additionalParameters" : { }
            },
            {
              "eventType" : "pageview",
              "conversionPlatform" : "Desktop",
              "conversionUrl" : "https://www.theguardian.com/technology/2022/mar/29/bitcoin-reduce-energy-consumption-climate-groups?utm_source=nextdraft&utm_medium=email",
              "advertiserInfo" : {
                "advertiserName" : "The Guardian",
                "screenName" : "@guardian"
              },
              "conversionValue" : "0",
              "conversionTime" : "2022-03-29 19:22:31",
              "additionalParameters" : { }
            },
            {
              "eventType" : "pageview",
              "conversionPlatform" : "Desktop",
              "conversionUrl" : "https://www.theguardian.com/technology/2022/mar/29/bitcoin-reduce-energy-consumption-climate-groups?utm_source=nextdraft&utm_medium=email",
              "advertiserInfo" : {
                "advertiserName" : "The Guardian",
                "screenName" : "@guardian"
              },
              "conversionValue" : "0",
              "conversionTime" : "2022-03-29 19:22:31",
              "additionalParameters" : { }
            },
            {
              "eventType" : "pageview",
              "conversionPlatform" : "Desktop",
              "conversionUrl" : "https://gen.xyz/",
              "advertiserInfo" : {
                "advertiserName" : "XYZ Domains | eth.xyz",
                "screenName" : "@xyz"
              },
              "conversionValue" : "0",
              "conversionTime" : "2022-03-29 19:38:17",
              "additionalParameters" : { }
            }
          ]
        }
      }
    }
  }
]