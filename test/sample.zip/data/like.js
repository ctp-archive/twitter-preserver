window.YTD.like.part0 = [
  {
    "like" : {
      "tweetId" : "1497320566268698629",
      "fullText" : "This is a tweet with a link https://t.co/CkxtZKWPef and then more text.",
      "expandedUrl" : "https://twitter.com/i/web/status/1497320566268698629"
    }
  }
]