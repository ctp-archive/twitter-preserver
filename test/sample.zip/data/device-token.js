window.YTD.device_token.part0 = [
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "FeXLU9eBLr8hemPCYWSVWXI9ScZemvwBmMppMfrO",
      "createdAt" : "2022-01-25T18:16:39.250Z",
      "lastSeenAt" : "2022-02-25T21:15:35.961Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  }
]